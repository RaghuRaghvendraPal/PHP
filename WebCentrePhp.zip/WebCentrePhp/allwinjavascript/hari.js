/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function abc()
             {
                  document.write("raju");
                  window.alert("hello");
                  document.write("sonu");
             }