<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    
                    
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
