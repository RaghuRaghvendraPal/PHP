<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $brandid=$_POST['ddlBrand'];
            $categoryid=$_POST['ddlCategory'];
            $productname=$_POST['txtProductName'];
            $price=$_POST['txtPrice'];
            $description=$_POST['txtDescription'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="INSERT INTO Product(BrandID,CategoryID,ProductName,Price,Description,LaunchDateTime) VALUES('$brandid','$categoryid','$productname','$price','$description',now())";
            
            mysql_query($query);
            
            mysql_close($con);
            
            header('Location: /ecommerceerpallwin/admin/productinsert.php');
            
        ?>
    </body>
</html>
