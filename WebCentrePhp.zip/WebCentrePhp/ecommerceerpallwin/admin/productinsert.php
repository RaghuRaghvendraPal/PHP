<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <form id="form1" name="form1" action="productinsertconfirm.php" method="post">
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                        <h1>Manage Product : </h1>
                    </div>
                    <div>
                        <table>
                            <tr>
                                <td>Brand</td>
                                <td>:</td>
                                <td>
                                    <select id="ddlBrand" name="ddlBrand">
                                        <option></option>
                                         <?php
            
                                            $con=  mysql_connect("localhost","root","");
                                            mysql_select_db("ecommerceerpallwin",$con);

                                            $query="SELECT * FROM Brand";

                                            $result=mysql_query($query);

                                            $num=  mysql_num_rows($result);

                                            mysql_close($con);

                                            $i=0;
                                            
                                            while($i<$num)
                                            {
                                                $id=mysql_result($result,$i,"ID");
                                                $brandtext=mysql_result($result,$i,"BrandText");

                                                ?>
                                        <option value="<?php echo $id; ?>"><?php echo $brandtext; ?></option>
                                                <?php

                                                $i++;
                                            }

                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Category</td>
                                <td>:</td>
                                <td>
                                    <select id="ddlCategory" name="ddlCategory">
                                        <option></option>
                                        <?php
            
                                            $con=  mysql_connect("localhost","root","");
                                            mysql_select_db("ecommerceerpallwin",$con);

                                            $query="SELECT * FROM Category";

                                            $result=mysql_query($query);

                                            $num=  mysql_num_rows($result);

                                            mysql_close($con);

                                            $i=0;
                                            
                                            while($i<$num)
                                            {
                                                $id=mysql_result($result,$i,"ID");
                                                $categorytext=mysql_result($result,$i,"CategoryText");

                                                ?>
                                        <option value="<?php echo $id; ?>"><?php echo $categorytext; ?></option>
                                                <?php

                                                $i++;
                                            }

                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Product Name</td>
                                <td>:</td>
                                <td>
                                    <input type="text" id="txtProductName" name="txtProductName"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Price</td>
                                <td>:</td>
                                <td>
                                    <input type="text" id="txtPrice" name="txtPrice" />
                                </td>
                            </tr>
                            <tr>
                                <td>Description</td>
                                <td>:</td>
                                <td>
                                    <textarea id="txtDescription" name="txtDescription" rows="3" cols="50"></textarea>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input type="submit" id="subInsert" name="subInsert" value="Insert"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div>
                         <?php
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT ID,BrandID,(SELECT Brand.BrandText FROM Brand WHERE Brand.ID=Product.BrandID) AS BRANDTEXT,CategoryID,(SELECT Category.CategoryText FROM Category WHERE Category.ID=Product.CategoryID) AS CATEGORYTEXT,ProductName,Price,Description,LaunchDateTime FROM Product ORDER BY ID DESC";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            ?>
                             <table border="1">
                                 <tr style="color: white; background-color: black; ">
                                     <th></th>
                                     <th></th>
                                     <th></th>
                                     <th></th>
                                     <th>ID</th>
                                     <th>Brand ID</th>
                                     <th>Brand Text</th>
                                     <th>Category ID</th>
                                     <th>Category Text</th>
                                     <th>Product Name</th>
                                     <th>Price</th>
                                     <th>Description</th>
                                     <th>Launch Date Time</th>
                                 </tr>
                            <?php
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $brandid=mysql_result($result,$i,"BrandID");
                                $brandtext=mysql_result($result,$i,"BRANDTEXT");
                                $categoryid=mysql_result($result,$i,"CategoryID");
                                $categorytext=mysql_result($result,$i,"CATEGORYTEXT");
                                $productname=mysql_result($result,$i,"ProductName");
                                $price=mysql_result($result,$i,"Price");
                                $description=mysql_result($result,$i,"Description");
                                $launchdatetime=mysql_result($result,$i,"LaunchDateTime");
                                
                                ?>
                                 <tr>
                                     <td><a href="javascript:void(0);" onclick="javascript:window.open('productphoto.php?ID=<?php echo $id; ?>','','width=350px,height=250px');">add/edit photo</a></td>
                                     <td><a href="productedit.php?ID=<?php echo $id; ?>">edit</a></td>
                                     <td><a href="javascript:void(0);" onclick="javascript:window.open('productdelete.php?ID=<?php echo $id; ?>','','width=200px,height=200px');">delete</a></td>
                                     <td>
                                         <img src="productphoto/<?php echo $id; ?>.jpg" alt="" style="width:80px; height: 80px;" id="img1" name="img1" />
                                     </td>
                                     <td><?php echo $id; ?></td>
                                     <td><?php echo $brandid; ?></td>
                                     <td><?php echo $brandtext; ?></td>
                                     <td><?php echo $categoryid; ?></td>
                                     <td><?php echo $categorytext; ?></td>
                                     <td><?php echo $productname; ?></td>
                                     <td><?php echo $price; ?></td>
                                     <td><?php echo $description; ?></td>
                                     <td><?php echo $launchdatetime; ?></td>
                                 </tr>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                             </table>
                    </div>
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
        </form>
    </body>
</html>
