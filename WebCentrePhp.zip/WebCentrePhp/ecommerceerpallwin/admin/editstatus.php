<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form id="form1" name="form1" action="editstatusconfirm.php" method="post">
        <?php
          $id=$_GET['ID'];
   
        ?>
        <div>
            <h2>Edit Status</h2>
        </div>
        <div>
            <table>
                <tr style="display: none;">
                    <td>ID</td>
                    <td>:</td>
                    <td>
                        <input type="text" id="txtID" name="txtID" value="<?php echo $id; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>:</td>
                    <td>
                        <select id="ddlStatus" name="ddlStatus">
                            <option value="0">PENDING</option>
                            <option value="1">SOLD</option>
                            <option value="2">CANCELED</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"></td>
                    <td>
                        <input type="submit" id="subupdate" name="subupdate" value="Update"/>
                    </td>
                </tr>
            </table>
        </div>
        </form>
    </body>
</html>
