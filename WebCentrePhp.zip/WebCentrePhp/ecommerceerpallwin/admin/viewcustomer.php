<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                        <h1>View Customer : </h1>
                    </div>
                    <div style="padding: 20px;">
                        <?php
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Customer";

                            $result=mysql_query($query);
                            
                            $num=mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            ?>
                             <table border="1">
                                 <tr style="color: white; background-color: black; ">
                                     <th>ID</th>
                                     <th>Customer Name</th>
                                     <th>Mob No</th>
                                     <th>Address</th>
                                     <th>Login ID</th>
                                     <th>Password</th>
                                 </tr>
                            <?php
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $customername=mysql_result($result,$i,"CustomerName");
                                $mobno=mysql_result($result,$i,"MobNo");
                                $address=mysql_result($result,$i,"Address");
                                $loginid=mysql_result($result,$i,"LoginID");
                                $password=mysql_result($result,$i,"Password");
                                
                                ?>
                                 <tr>
                                    <td><?php echo $id; ?></td>
                                     <td><?php echo $customername; ?></td>
                                     <td><?php echo $mobno; ?></td>
                                     <td><?php echo $address; ?></td>
                                     <td><?php echo $loginid; ?></td>
                                     <td><?php echo $password; ?></td>
                                 </tr>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                             </table>
                    </div>
                    
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
