<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $id=$_GET['ID'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="DELETE FROM Product WHERE ID='$id'";
            
            mysql_query($query);
            
            mysql_close($con);
            
            
        ?>
        <h3>RECORD DELETED - PLEASE REFRESH PAGE</h3>
    </body>
</html>
