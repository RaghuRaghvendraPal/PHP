<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php 
            $id=$_POST['txtID'];
        
            $status=$_POST['ddlStatus'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="UPDATE Cart SET status='$status' WHERE ID='$id'";
            
            mysql_query($query);
            
            mysql_close($con);
            
        ?>
        <h3>RECORD UPDATED - REFRESH PAGE</h3>
    </body>
</html>
