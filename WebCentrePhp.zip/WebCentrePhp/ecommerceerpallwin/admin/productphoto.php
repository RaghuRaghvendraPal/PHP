<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form id="form1" name="form1" action="productphotoconfirm.php" method="post" enctype="multipart/form-data">
            <?php
               $id=$_GET['ID'];
            ?>
            <div>
                <h3>Upload Photo : </h3>
            </div>
            <div>
                <table>
                    <tr style="display: none;">
                        <td>ID</td>
                        <td>:</td>
                        <td>
                            <input value="<?php echo $id; ?>" type="text" id="txtID" name="txtID"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Upload</td>
                        <td>:</td>
                        <td>
                            <input type="file" id="upload" name="upload"/>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"></td>
                        <td>
                            <input type="submit" id="subphoto" name="subphoto" value="Click To Upload"/>
                        </td>
                    </tr>
                </table>
            </div>
        </form>
    </body>
</html>
