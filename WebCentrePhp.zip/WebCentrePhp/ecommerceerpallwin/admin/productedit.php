<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <form id="form1" name="form1" action="producteditconfirm.php" method="post">
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                     <div>
                         <?php
                         
                            $productidurl=$_GET['ID'];
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT ID,BrandID,(SELECT Brand.BrandText FROM Brand WHERE Brand.ID=Product.BrandID) AS BRANDTEXT,CategoryID,(SELECT Category.CategoryText FROM Category WHERE Category.ID=Product.CategoryID) AS CATEGORYTEXT,ProductName,Price,Description,LaunchDateTime FROM Product WHERE ID='$productidurl'";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                               $brandid=mysql_result($result,$i,"BrandID");
                                $brandtext=mysql_result($result,$i,"BRANDTEXT");
                                $categoryid=mysql_result($result,$i,"CategoryID");
                                $categorytext=mysql_result($result,$i,"CATEGORYTEXT");
                                $productname=mysql_result($result,$i,"ProductName");
                                $price=mysql_result($result,$i,"Price");
                                $description=mysql_result($result,$i,"Description");
                                $launchdatetime=mysql_result($result,$i,"LaunchDateTime");
                                
                                

                         ?>
                    </div>
                    <div>
                        <h1>Update Product : </h1>
                    </div>
                    <div>
                        <table>
                            <tr style="display: none;">
                                <td>ID</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $productidurl; ?>" type="text" id="txtID" name="txtID"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Brand</td>
                                <td>:</td>
                                <td>
                                    <select id="ddlBrand" name="ddlBrand">
                                        <option></option>
                                         <?php
            
                                            $con=  mysql_connect("localhost","root","");
                                            mysql_select_db("ecommerceerpallwin",$con);

                                            $query="SELECT * FROM Brand";

                                            $result=mysql_query($query);

                                            $num=  mysql_num_rows($result);

                                            mysql_close($con);

                                            $i=0;
                                            
                                            while($i<$num)
                                            {
                                                $id=mysql_result($result,$i,"ID");
                                                $brandtext=mysql_result($result,$i,"BrandText");
                                                    if($id==$brandid)
                                                    {
                                                        ?>
                                                
                                        <option selected="selected" value="<?php echo $id; ?>"><?php echo $brandtext; ?></option>
                                                <?php
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                
                                        <option value="<?php echo $id; ?>"><?php echo $brandtext; ?></option>
                                                <?php
                                                    }
                                                

                                                $i++;
                                            }

                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Category</td>
                                <td>:</td>
                                <td>
                                    <select id="ddlCategory" name="ddlCategory">
                                        <option></option>
                                        <?php
            
                                            $con=  mysql_connect("localhost","root","");
                                            mysql_select_db("ecommerceerpallwin",$con);

                                            $query="SELECT * FROM Category";

                                            $result=mysql_query($query);

                                            $num=  mysql_num_rows($result);

                                            mysql_close($con);

                                            $i=0;
                                            
                                            while($i<$num)
                                            {
                                                $id=mysql_result($result,$i,"ID");
                                                $categorytext=mysql_result($result,$i,"CategoryText");
                                                
                                                if($id==$categoryid)
                                                {
                                                    ?>
                                        <option selected="selected" value="<?php echo $id; ?>"><?php echo $categorytext; ?></option>
                                                <?php
                                                }
                                                else
                                                {
                                                    ?>
                                        <option value="<?php echo $id; ?>"><?php echo $categorytext; ?></option>
                                                <?php
                                                }
                                                

                                                $i++;
                                            }

                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Product Name</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $productname; ?>" type="text" id="txtProductName" name="txtProductName"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Price</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $price; ?>" type="text" id="txtPrice" name="txtPrice" />
                                </td>
                            </tr>
                            <tr>
                                <td>Description</td>
                                <td>:</td>
                                <td>
                                    <textarea id="txtDescription" name="txtDescription" rows="3" cols="50"><?php echo $description; ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input type="submit" id="subUpdate" name="subUpdate" value="Update"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                   
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
        </form>
    </body>
</html>
