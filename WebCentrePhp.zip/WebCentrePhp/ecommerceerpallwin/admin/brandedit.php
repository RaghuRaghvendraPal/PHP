<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form id="form1" name="form1" action="brandeditconfirm.php" method="post">
        <?php
           $id=$_GET['ID'];
        
            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Brand WHERE ID='$id'";

                            $result=mysql_query($query);

                            mysql_close($con);
                            
                            $brandtext=mysql_result($result,0,"BrandText");
        
        ?>
        <div>
                        <h1>Update Brand : </h1>
                    </div>
                    <div>
                        <table>
                            <tr style="display: none;">
                                <td>ID</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $id; ?>" type="text" id="txtID" name="txtID"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Brand Text</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $brandtext; ?>" type="text" id="txtBrandText" name="txtBrandText"/>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input type="submit" id="subupdate" name="subupdate" value="Update"/>
                                </td>
                            </tr>
                        </table>
                    </div>
        </form>
    </body>
</html>
