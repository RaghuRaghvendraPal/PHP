<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                        <h1>Manage Cart : </h1>
                    </div>
                    
                    <div>
                    <?php
                          
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT *,(SELECT Product.ProductName FROM Product WHERE Product.ID=Cart.ProductID) AS PRODUCTNAME FROM Cart ORDER BY ID DESC";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            ?>
                             <table border="1">
                                 <tr style="color: white; background-color: black; ">
                                     <th></th>
                                     <th>Trans ID</th>
                                     <th>Customer ID</th>
                                     <th></th>
                                     <th>Product ID</th>
                                     <th>Product Name</th>
                                     <th>Price</th>
                                     <th>Quantity</th>
                                     <th>Status</th>
                                     <th>Date Time</th>
                                 </tr>
                            <?php
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $customerid=mysql_result($result,$i,"CustomerID");
                                $productid=mysql_result($result,$i,"ProductID");
                                $productname=mysql_result($result,$i,"PRODUCTNAME");
                                $price=mysql_result($result,$i,"Price");
                                $quantity=mysql_result($result,$i,"Quantity");
                                $status=mysql_result($result,$i,"Status");
                                $addtodatetime=mysql_result($result,$i,"AddToDateTime");
                                
                                ?>
                                 <tr>
                                     <td>
                                         <a onclick="javascript:window.open('editstatus.php?ID=<?php echo $id; ?>','','width=300px,height=300px');" href="javascript:void(0);">EDIT STATUS</a>
                                     </td>
                                     <td><?php echo $id; ?></td>
                                     <td><?php echo $customerid; ?></td>
                                     <td>
                                         <img src="productphoto/<?php echo $productid; ?>.jpg" alt="" style="width:60px; height: 60px;"/>
                                     </td>
                                     <td><?php echo $productid; ?></td>
                                     <td><?php echo $productname; ?></td>
                                     <td><?php echo $price; ?></td>
                                     <td><?php echo $quantity; ?></td>
                                     <td>
                                         <?php 
                                            if($status==0)
                                            {
                                                ?>PENDING<?php
                                            }
                                            if($status==1)
                                            {
                                                ?>SOLD<?php
                                            }
                                            if($status==2)
                                            {
                                                ?>CANCELED<?php
                                            }
                                         ?>
                                     </td>
                                     <td><?php echo $addtodatetime; ?></td>
                                 </tr>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                             </table>
                    </div>
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
