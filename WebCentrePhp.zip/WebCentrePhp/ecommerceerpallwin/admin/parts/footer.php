<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <table style="width:960px; height: 40px;
                background-color: #534567;">
            <tr>
                <td>
                    &nbsp;
                </td>
            </tr>
        </table>
    </body>
</html>
