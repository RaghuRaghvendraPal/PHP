<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <table style="width:960px; height: 100px;
                background-color: #534567;">
            <tr>
                <td style="text-align: center; font-size: 40px; letter-spacing: 10px;
                     color: #857796; font-weight: bold; font-family: algerian;">
                    ADMIN SECTION
                </td>
            </tr>
        </table>
    </body>
</html>
