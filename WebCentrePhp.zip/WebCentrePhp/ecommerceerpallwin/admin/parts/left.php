<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <style type="text/css">
            a.MenuLink
            {
                width:160px;
                color: white;
                background-color: #774577;
                display: block;
                text-decoration: none;
                border-bottom-color: white;
                border-bottom-style: solid;
                border-bottom-width: 1px;
                padding: 3px 0px 3px 3px;
                font-weight: bold;
            }
            
            a.MenuLink:hover
            {
                background-color: #976597;
            }
        </style>
    </head>
    <body>
        <table border="0" cellspacing="0" cellpadding="0" style="width:160px;">
            <tr>
                <td>
                    <a class="MenuLink" href="adminwelcome.php">Welcome</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="brandinsert.php">Manage Brand</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="categoryinsert.php">Manage Category</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="productinsert.php">Manage Product</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="managecart.php">Manage Cart</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="viewcustomer.php">View Customer</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="../adminlogin.php">Admin LogOut</a>
                </td>
            </tr>
        </table>
    </body>
</html>
