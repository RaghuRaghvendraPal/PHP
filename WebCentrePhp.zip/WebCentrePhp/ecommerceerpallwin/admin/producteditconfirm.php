<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $id=$_POST['txtID'];
            $brandid=$_POST['ddlBrand'];
            $categoryid=$_POST['ddlCategory'];
            $productname=$_POST['txtProductName'];
            $price=$_POST['txtPrice'];
            $description=$_POST['txtDescription'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="UPDATE Product SET BrandID='$brandid',CategoryID='$categoryid',ProductName='$productname',Price='$price',Description='$description' WHERE ID='$id'";
            
            mysql_query($query);
            
            mysql_close($con);
            
            header('Location: /ecommerceerpallwin/admin/productinsert.php');
            
        ?>
    </body>
</html>
