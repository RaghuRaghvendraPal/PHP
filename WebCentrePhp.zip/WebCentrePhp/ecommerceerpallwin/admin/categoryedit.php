<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form id="form1" name="form1" action="categoryeditconfirm.php" method="post">
        <?php
           $id=$_GET['ID'];
        
            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Category WHERE ID='$id'";

                            $result=mysql_query($query);

                            mysql_close($con);
                            
                            $categorytext=mysql_result($result,0,"CategoryText");
        
        ?>
        <div>
                        <h1>Update Category : </h1>
                    </div>
                    <div>
                        <table>
                            <tr style="display: none;">
                                <td>ID</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $id; ?>" type="text" id="txtID" name="txtID"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Category Text</td>
                                <td>:</td>
                                <td>
                                    <input value="<?php echo $categorytext; ?>" type="text" id="txtCategoryText" name="txtCategoryText"/>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input type="submit" id="subupdate" name="subupdate" value="Update"/>
                                </td>
                            </tr>
                        </table>
                    </div>
        </form>
    </body>
</html>
