<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $categorytext=$_POST['txtCategoryText'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="INSERT INTO Category(CategoryText) VALUES('$categorytext')";
            
            mysql_query($query);
            
            mysql_close($con);
            
            header('Location: /ecommerceerpallwin/admin/categoryinsert.php');
            
        ?>
    </body>
</html>
