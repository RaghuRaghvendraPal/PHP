<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <form id="form1" name="form1" action="brandinsertconfirm.php" method="post">
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="2">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                        <h1>Manage Brand : </h1>
                    </div>
                    <div>
                        <table>
                            <tr>
                                <td>Brand Text</td>
                                <td>:</td>
                                <td>
                                    <input type="text" id="txtBrandText" name="txtBrandText"/>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input type="submit" id="subinsert" name="subinsert" value="Insert"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div style="padding: 20px;">
                        <?php
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Brand";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            ?>
                             <table border="1">
                                 <tr style="color: white; background-color: black; ">
                                     <th></th>
                                     <th></th>
                                     <th>ID</th>
                                     <th>Brand Text</th>
                                 </tr>
                            <?php
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $brandtext=mysql_result($result,$i,"BrandText");
                                
                                ?>
                                 <tr>
                                     <td><a href="javascript:void(0);" onclick="javascript:window.open('brandedit.php?ID=<?php echo $id; ?>','','width=300px,height=300px');">edit</a></td>
                                     <td><a href="javascript:void(0);" onclick="javascript:window.open('branddelete.php?ID=<?php echo $id; ?>','','width=200px,height=200px');">delete</a></td>
                                     <td><?php echo $id; ?></td>
                                     <td><?php echo $brandtext; ?></td>
                                 </tr>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                             </table>
                    </div>
                    
                </td>
            </tr>
            <tr class="footersection">
                <td colspan="2"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
        </form>
    </body>
</html>
