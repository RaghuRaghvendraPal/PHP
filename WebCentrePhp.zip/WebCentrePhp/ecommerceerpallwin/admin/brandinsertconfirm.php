<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $brandtext=$_POST['txtBrandText'];
            
            $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="INSERT INTO Brand(BrandText) VALUES('$brandtext')";
            
            mysql_query($query);
            
            mysql_close($con);
            
            header('Location: /ecommerceerpallwin/admin/brandinsert.php');
            
        ?>
    </body>
</html>
