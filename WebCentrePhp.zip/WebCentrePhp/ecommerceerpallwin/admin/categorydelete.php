<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body style="background-color: #ABABDD;">
        <?php
           $id=$_GET['ID'];
        ?>
        <table style="width: 100%; text-align: center;">
            <tr>
                <td colspan="2">
                    <b>ARE YOU SURE TO DELETE THIS RECORD</b>
                </td>
            </tr>
            <tr style="font-weight: bold; font-size: 20px;">
                <td>
                    <a style="color:red;" href="categorydeleteconfirm.php?ID=<?php echo $id; ?>">YES</a>
                </td>
                <td>
                    <a style="color:green;" href="javascript:window.close();">NO</a>
                </td>
            </tr>
        </table>
    </body>
</html>
