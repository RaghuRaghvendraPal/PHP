<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
          $loginid=$_GET['loginid'];
          $password=$_GET['password'];
          
           $con=  mysql_connect("localhost","root","");
           mysql_select_db("ecommerceerpallwin",$con);

           $query="SELECT count(*) FROM Customer WHERE LoginID='$loginid' AND Password='$password'";

           $result=mysql_query($query);
                            
           mysql_close($con);
           
           $count=mysql_result($result,0,0);
           
           if($count==0)
           {
               header('Location: /ecommerceerpallwin/customerlogin.php');
           }
           else
           {
               header('Location: /ecommerceerpallwin/customercreatesession.php?loginid='.$loginid.'&password='.$password);
           }
        ?>
    </body>
</html>
