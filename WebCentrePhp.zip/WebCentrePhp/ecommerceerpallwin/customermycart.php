<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
        
    </head>
    <body>
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="3">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                        <h1>Customer My Cart : </h1>
                    </div>
                    <div>
                    <?php
                           $customerid=$_SESSION['CUSTOMERID']; 
                    
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT *,(SELECT Product.ProductName FROM Product WHERE Product.ID=Cart.ProductID) AS PRODUCTNAME FROM Cart WHERE CustomerID='$customerid' ORDER BY ID DESC";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            ?>
                             <table border="1">
                                 <tr style="color: white; background-color: black; ">
                                     <th>Trans ID</th>
                                     <th></th>
                                     <th>Product Name</th>
                                     <th>Price</th>
                                     <th>Quantity</th>
                                     <th>Status</th>
                                     <th>Date Time</th>
                                 </tr>
                            <?php
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $productid=mysql_result($result,$i,"ProductID");
                                $productname=mysql_result($result,$i,"PRODUCTNAME");
                                $price=mysql_result($result,$i,"Price");
                                $quantity=mysql_result($result,$i,"Quantity");
                                $status=mysql_result($result,$i,"Status");
                                $addtodatetime=mysql_result($result,$i,"AddToDateTime");
                                
                                ?>
                                 <tr>
                                     <td><?php echo $id; ?></td>
                                     <td>
                                         <img src="admin/productphoto/<?php echo $productid; ?>.jpg" alt="" style="width:60px; height: 60px;"/>
                                     </td>
                                     <td><?php echo $productname; ?></td>
                                     <td><?php echo $price; ?></td>
                                     <td><?php echo $quantity; ?></td>
                                     <td>
                                         <?php 
                                            if($status==0)
                                            {
                                                ?>PENDING<?php
                                            }
                                            if($status==1)
                                            {
                                                ?>SOLD<?php
                                            }
                                            if($status==2)
                                            {
                                                ?>CANCELED<?php
                                            }
                                         ?>
                                     </td>
                                     <td><?php echo $addtodatetime; ?></td>
                                 </tr>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                             </table>
                    </div>
                </td>
                <td class="rightsection"><?php include 'parts/right.php'; ?></td>
            </tr>
            <tr class="footersection">
                <td colspan="3"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
