/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function login()
{
    var loginid=document.getElementById("txtLoginID").value;
    var password=document.getElementById("txtPassword").value;
    
    if(loginid=="alwin")
        {
            if(password=="alwin")
                {
                    window.location="admin/adminwelcome.php";
                }
                else
                    {
                        alert("login details not correct");
                    }
        }
        else
        {
             alert("login details not correct");
        }
}


