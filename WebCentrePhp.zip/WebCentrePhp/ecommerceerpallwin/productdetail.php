<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link type="text/css" href="main.css" rel="StyleSheet"/>
    </head>
    <body>
        <table class="projectlayout" align="center" border="0"
                cellspacing="0" cellpadding="0">
            <tr class="headersection">
                <td colspan="3">
                    <?php include 'parts/header.php'; ?>
                </td>
            </tr>
            <tr class="middlesection">
                <td class="leftsection"><?php include 'parts/left.php'; ?></td>
                <td class="bodysection">
                    <div>
                         <?php
                         
                            $productidurl=$_GET['ID'];
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT ID,BrandID,(SELECT Brand.BrandText FROM Brand WHERE Brand.ID=Product.BrandID) AS BRANDTEXT,CategoryID,(SELECT Category.CategoryText FROM Category WHERE Category.ID=Product.CategoryID) AS CATEGORYTEXT,ProductName,Price,Description,LaunchDateTime FROM Product WHERE ID='$productidurl'";

                            $result=mysql_query($query);
                            
                            mysql_close($con);
                            
                            $i=0;
                            
                            $brandid=mysql_result($result,$i,"BrandID");
                            $brandtext=mysql_result($result,$i,"BRANDTEXT");
                            $categoryid=mysql_result($result,$i,"CategoryID");
                            $categorytext=mysql_result($result,$i,"CATEGORYTEXT");
                            $productname=mysql_result($result,$i,"ProductName");
                            $price=mysql_result($result,$i,"Price");
                            $description=mysql_result($result,$i,"Description");
                            $launchdatetime=mysql_result($result,$i,"LaunchDateTime");
                         ?> 
                               
                        <div style="margin-bottom: 2px; margin-top: 2px;">
                        <table border="1" rules="none" style="width:590px;">
                            <tr>
                                <td style="width:310px; vertical-align: top;">
                                    <img src="admin/productphoto/<?php echo $productidurl; ?>.jpg" alt="" style="width:300px;"/>
                                </td>
                                <td style="width:280px; vertical-align: top;">
                                    <div>
                                        <h1 style="color:#456677;">   <?php echo $productname; ?></h1>
                                    </div>
                                    <div>
                                        <table>
                                            <tr style="color:gray;">
                                                <td>Launched On</td>
                                                <td>:</td>
                                                <td> <?php echo $launchdatetime; ?></td>
                                            </tr>
                                        </table>
                                        
                                    </div>
                                    <div style="margin-top:15px;">
                                        <table>
                                            <tr>
                                                <td>Category</td>
                                                <td>:</td>
                                                <td>
                                                    <?php echo $categorytext; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Brand</td>
                                                <td>:</td>
                                                <td>
                                                    <?php echo $brandtext; ?>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div style="font-size:25px;margin-top: 20px;">
                                        Price :<span style="color:red;"> <?php echo $price; ?></span>
                                    </div><br><br>
                                    <div>
                                        <?php
                                             if(isset($_SESSION['CUSTOMERID']))
                {                            {
                }                               ?>
                                        <a href="javascript:void(0);" onclick="javascript:window.open('cartinsert.php?productid=<?php echo $productidurl; ?>','','width=300px,height=300px');" style="color:green;">ADD TO CART</a>
                                                <?php
                                             }
                                             else
                                             {
                                                ?>
                                        <h4 style="color:red;">PLEASE LOGIN TO ADD TO CART</h4>
                                                <?php
                                             }
                                        ?>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"><hr>
                                    <?php echo $description; ?>
                                </td>
                            </tr>
                        </table>
                        </div>
                    </div>
                    
                </td>
                <td class="rightsection"><?php include 'parts/right.php'; ?></td>
            </tr>
            <tr class="footersection">
                <td colspan="3"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
