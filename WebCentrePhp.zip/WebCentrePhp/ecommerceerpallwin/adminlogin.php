<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
       
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
      <title></title>
      
  <link type="text/css" href="main.css" rel="StyleSheet"/>
      
  <script src="login.js" type="text/javascript" language="javascript">
      
  </script>
  
  </head>
   
 <body>
       
 <table class="projectlayout" align="center" border="0"
 cellspacing="0" cellpadding="0">
      
 <tr class="headersection">
 
 <td colspan="3">
                    
 <?php include 'parts/header.php'; ?>
               
 </td>
         
 </tr>
           
  <tr class="middlesection">
              
  <td class="leftsection"><?php include 'parts/left.php'; ?></td>
 
  <td class="bodysection">
                  
  <div>
                    
  <h1>Admin Login : </h1>
                 
  </div>
                 
  <div style="padding-left: 20px; padding-top: 20px;">
                   
    <table border="1" rules="none" style="background-color: #CCEEFF;">
                            <tr>
                                <td>Login ID</td>
                                <td>:</td>
                                <td>
                                    <input type="text" id="txtLoginID" name="txtLoginID"/>
                                </td>
                            </tr>
                            <tr>
                                <td>Password</td>
                                <td>:</td>
                                <td>
                                    <input type="password" id="txtPassword" name="txtPassword"/>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                                <td>
                                    <input onclick="javascript:login();" type="button" id="btnlogin" name="btnlogin" value="LogIn"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                </td>
                <td class="rightsection"><?php include 'parts/right.php'; ?></td>
            </tr>
            <tr class="footersection">
                <td colspan="3"><?php include 'parts/footer.php'; ?></td>
            </tr>
        </table>
    </body>
</html>
