<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
           session_start();
           
           $customerid=$_SESSION['CUSTOMERID'];
        
           $productid=$_POST['txtProductID'];
           
           $price=$_POST['txtPrice'];
           
           $quantity=$_POST['txtQuantity'];
           
           $con=  mysql_connect("localhost","root","");
            mysql_select_db("ecommerceerpallwin",$con);
            
            $query="INSERT INTO Cart(CustomerID,ProductID,Price,Quantity,Status,AddToDateTime) VALUES('$customerid','$productid','$price','$quantity',0,now())";
            
            mysql_query($query);
            
            mysql_close($con);
           
           
        ?>
        <h3>WAIT FOR OUR SALES TEAM</h3>
    </body>
</html>
