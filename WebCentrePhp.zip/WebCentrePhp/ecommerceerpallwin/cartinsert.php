<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
       <form id="form1" name="form1" action="cartinsertconfirm.php" method="post">
        <?php
           
           $productid=$_GET['productid'];
           
           $con=  mysql_connect("localhost","root","");
           mysql_select_db("ecommerceerpallwin",$con);

           $query="SELECT Price FROM Product WHERE ID='$productid'";

           $result=mysql_query($query);
                            
           mysql_close($con);
                            
           $price=mysql_result($result,0,0);
        ?>
           <h3>
               CART SUBMISSION :
           </h3>
           <div>
               <table>
                   <tr style="display: none;">
                       <td>Product ID</td>
                       <td>:</td>
                       <td>
                           <input value="<?php echo $productid; ?>" type="text" id="txtProductID" name="txtProductID" />
                       </td>
                   </tr>
                   <tr style="display: none;">
                       <td>Price</td>
                       <td>:</td>
                       <td>
                           <input value="<?php echo $price; ?>" type="text" id="txtPrice" name="txtPrice"/>
                       </td>
                   </tr>
                   <tr>
                       <td>Quantity</td>
                       <td>:</td>
                       <td>
                           <input type="text" id="txtQuantity" name="txtQuantity" value="1" style="width:50px;" />
                       </td>
                   </tr>
                   <tr>
                       <td colspan="2"></td>
                       <td>
                           <input type="submit" id="subinsert" name="subinsert" value="Click To Add To CART" />
                       </td>
                   </tr>
               </table>
           </div>
       </form>
    </body>
</html>
