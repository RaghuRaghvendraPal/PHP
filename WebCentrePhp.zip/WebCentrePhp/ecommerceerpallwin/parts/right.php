<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <style type="text/css">
            a.CategoryLink
            {
                width:200px;
                color: white;
                background-color: #457007;
                display: block;
                text-decoration: none;
                border-bottom-color: white;
                border-bottom-style: solid;
                border-bottom-width: 1px;
                padding: 3px 0px 3px 3px;
                font-weight: bold;
            }
            
            a.CategoryLink:hover
            {
                background-color: #659447;
            }
        </style>
        
        <script type="text/javascript" language="javascript">
            function search()
            {
                var searchtext=document.getElementById("txtSearch").value;
                
                if(searchtext!="")
                    {
                        window.location="searchoutput.php?searchtext="+searchtext;
                    }
            }
        </script>
    </head>
    <body>
        <div>
            <table BORDER="1" rules="none" style="width:100%; background-color: #909090;">
                <tr>
                    <td>
                        <input type="text" id="txtSearch" name="txtSearch"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input onclick="javascript:search();" type="button" id="btnsearch" name="btnsearch" value="SEARCH GO"/>
                    </td>
                </tr>
            </table>
        </div>
        
        <div STYLE="color:white; background-color: black; font-weight: bold; padding: 1px;">
            Categories : 
        </div>
       <div>
                        <?php
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Category";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $categorytext=mysql_result($result,$i,"CategoryText");
                                
                                ?>
                                <a class="CategoryLink" href="categoryproduct.php?categoryid=<?php echo $id; ?>"><?php echo $categorytext; ?></a>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                    </div>
    </body>
</html>
