<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <style type="text/css">
            a.MenuLink
            {
                width:160px;
                color: white;
                background-color: #457777;
                display: block;
                text-decoration: none;
                border-bottom-color: white;
                border-bottom-style: solid;
                border-bottom-width: 1px;
                padding: 3px 0px 3px 3px;
                font-weight: bold;
            }
            
            a.MenuLink:hover
            {
                background-color: #659797;
            }
            
            
            a.BrandLink
            {
                width:160px;
                color: white;
                background-color: #452277;
                display: block;
                text-decoration: none;
                border-bottom-color: white;
                border-bottom-style: solid;
                border-bottom-width: 1px;
                padding: 3px 0px 3px 3px;
                font-weight: bold;
            }
            
            a.BrandLink:hover
            {
                background-color: #654497;
            }
        </style>
    </head>
    <body>
        <table border="0" cellspacing="0" cellpadding="0" style="width:160px;">
            <tr>
                <td>
                    <a class="MenuLink" href="index.php">Home</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="customerregistration.php">Customer Registration</a>
                </td>
            </tr>
            <?php
                if(isset($_SESSION['CUSTOMERID']))
                {
                    ?>
            <tr>
                <td>
                    <a class="MenuLink" href="customermycart.php">Customer My Cart</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a class="MenuLink" href="customerkillsession.php">Customer LogOut</a>
                </td>
            </tr>
                    <?php
                }
                else
                {
                    ?>
            <tr>
                <td>
                    <a class="MenuLink" href="customerlogin.php">Customer Login</a>
                </td>
            </tr>
                     <?php
                }
            ?>
            
            
            <tr>
                <td>
                    <a class="MenuLink" href="adminlogin.php">Admin Login</a>
                </td>
            </tr>
        </table>
        
        <br><br>
        
         <div STYLE="color:white; background-color: black; font-weight: bold; padding: 1px;">
            Brands : 
        </div>
       <div>
                        <?php
            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT * FROM Brand";

                            $result=mysql_query($query);
                            
                            $num=  mysql_num_rows($result);

                            mysql_close($con);
                            
                            $i=0;
                            
                            
                            
                            while($i<$num)
                            {
                                $id=mysql_result($result,$i,"ID");
                                $brandtext=mysql_result($result,$i,"BrandText");
                                
                                ?>
                                <a class="BrandLink" href="brandproduct.php?brandid=<?php echo $id; ?>"><?php echo $brandtext; ?></a>
                                 <?php
                                
                                $i++;
                            }

                         ?>
                    </div>
    </body>
</html>
