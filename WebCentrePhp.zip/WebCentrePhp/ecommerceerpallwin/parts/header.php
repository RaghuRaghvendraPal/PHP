<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
           session_start();
        ?>
        <table style="width:960px; height: 100px;
                background-color: #234567;">
            <tr>
                <td style="text-align: center; font-size: 30px; letter-spacing: 10px;
                     color: #557796; font-weight: bold; font-family: algerian;">
                    ECOMMERCE - ERP <br>
                    <?php
                        if(isset($_SESSION['CUSTOMERID'])) 
                         {
                            $customerid=$_SESSION['CUSTOMERID']; 
                            
                            $con=  mysql_connect("localhost","root","");
                            mysql_select_db("ecommerceerpallwin",$con);

                            $query="SELECT CustomerName FROM Customer WHERE ID='$customerid'";

                            $result=mysql_query($query);
                            
                            mysql_close($con);
           
                            $customername=mysql_result($result,0,0);
                            
                            ?>
                          <span style="color:red; font-size: 18px;"> ( WELCOME - <?php echo $customername; ?> ) </span>
                            <?php
                         }
                    ?>
                </td>
            </tr>
        </table>
    </body>
</html>
